export const Property__c = {
    objectApiName: 'Property__c',
    Date_Listed__c: { fieldApiName: 'Date_Listed__c' },
    Days_On_Market__c: { fieldApiName: 'Days_On_Market__c' }
};
